# vibesearch

A fun, vibe-based searching algorithm — totally not serious!

## Installation
pip install vibesearch

## Usage
```python
from vibesearch import vibesearch

print(vibesearch([3, 1, 4, 1, 5], 4))
```
## Notes
This project is just for fun and not meant for real-world use.

